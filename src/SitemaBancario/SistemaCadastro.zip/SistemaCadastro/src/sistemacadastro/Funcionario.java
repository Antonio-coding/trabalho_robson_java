package sistemacadastro;

public class Funcionario {
    public String nome;
    public double salario;
    
    public Funcionario(){
        nome = "";
        salario = 0.0;
    }
}
